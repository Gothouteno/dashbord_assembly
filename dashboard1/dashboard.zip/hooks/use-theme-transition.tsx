"use client"

import { useTheme } from "next-themes"
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react"

type ThemeMode = "light" | "dark"

interface ThemeTransitionContextType {
  isTransitioning: boolean
  overlayTheme: ThemeMode
  toggleTheme: () => void
}

const DEFAULT_THEME: ThemeMode = "light"

const ThemeTransitionContext = createContext<ThemeTransitionContextType | undefined>(
  undefined
)

const sanitizeTheme = (value?: string): ThemeMode => (value === "dark" ? "dark" : "light")

export function ThemeTransitionProvider({ children }: { children: React.ReactNode }) {
  const { resolvedTheme, setTheme } = useTheme()
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [overlayTheme, setOverlayTheme] = useState<ThemeMode>(DEFAULT_THEME)
  const timeoutsRef = useRef<number[]>([])

  const clearTimers = useCallback(() => {
    timeoutsRef.current.forEach((id) => window.clearTimeout(id))
    timeoutsRef.current = []
  }, [])

  const scheduleTimeout = useCallback(
    (handler: () => void, delay: number) => {
      const id = window.setTimeout(handler, delay)
      timeoutsRef.current.push(id)
      return id
    },
    []
  )

  useEffect(() => {
    return () => {
      clearTimers()
    }
  }, [clearTimers])

  useEffect(() => {
    if (!isTransitioning && resolvedTheme) {
      setOverlayTheme(sanitizeTheme(resolvedTheme))
    }
  }, [isTransitioning, resolvedTheme])

  const toggleTheme = useCallback(() => {
    if (isTransitioning) {
      return
    }

    const currentTheme = sanitizeTheme(resolvedTheme)
    const targetTheme: ThemeMode = currentTheme === "light" ? "dark" : "light"

    clearTimers()
    setOverlayTheme(targetTheme)
    setIsTransitioning(true)

    scheduleTimeout(() => setTheme(targetTheme), 80)
    scheduleTimeout(() => {
      setIsTransitioning(false)
      setOverlayTheme(targetTheme)
      clearTimers()
    }, 500)
  }, [clearTimers, isTransitioning, resolvedTheme, scheduleTimeout, setTheme])

  const value = useMemo(
    () => ({ isTransitioning, overlayTheme, toggleTheme }),
    [isTransitioning, overlayTheme, toggleTheme]
  )

  return <ThemeTransitionContext.Provider value={value}>{children}</ThemeTransitionContext.Provider>
}

export function useThemeTransition() {
  const context = useContext(ThemeTransitionContext)
  if (context === undefined) {
    throw new Error("useThemeTransition must be used within a ThemeTransitionProvider")
  }
  return context
}
