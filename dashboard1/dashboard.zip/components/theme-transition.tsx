"use client"

import { useEffect, useMemo, useState } from "react"
import { useThemeTransition } from "@/hooks/use-theme-transition.tsx"

export function ThemeTransition() {
  const { isTransitioning, overlayTheme } = useThemeTransition()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const { background, shadow } = useMemo(() => {
    if (overlayTheme === "dark") {
      return {
        background:
          "radial-gradient(circle at center, rgba(15,23,42,0.95) 0%, rgba(3,7,18,0.98) 55%, rgba(2,8,23,1) 100%)",
        shadow: "0 0 70px rgba(2,8,23,0.45)",
      }
    }

    return {
      background:
        "radial-gradient(circle at center, rgba(248,250,252,0.96) 0%, rgba(255,255,255,1) 55%, rgba(241,245,249,0.95) 100%)",
      shadow: "0 0 60px rgba(255,255,255,0.55)",
    }
  }, [overlayTheme])

  if (!mounted && !isTransitioning) {
    return null
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        pointerEvents: "none",
        zIndex: 9999,
        display: isTransitioning ? "flex" : "none",
        alignItems: "center",
        justifyContent: "center",
        mixBlendMode: "normal",
      }}
    >
      <div
        style={{
          width: "140vmax",
          height: "140vmax",
          borderRadius: "50%",
          background,
          boxShadow: shadow,
          transform: isTransitioning ? "scale(1)" : "scale(0.05)",
          opacity: isTransitioning ? 1 : 0,
          transition:
            "transform 400ms cubic-bezier(0.4, 0, 0.2, 1), opacity 250ms ease, box-shadow 300ms ease",
          willChange: "transform, opacity",
        }}
      />
    </div>
  )
}
